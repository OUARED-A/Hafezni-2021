package com.mostefalmr.hafezni

class CheckboxModel {
    var text:String? = null
    constructor(text:String){
        this.text = text
    }
}