package com.mostefalmr.hafezni

class ModuleModel {
    var name:String?= null
    var percentage:Double? = null


    constructor(name:String, percentage:Double){
        this.name = name
        this.percentage=percentage

    }
}